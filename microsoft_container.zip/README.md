# Microsoft Container

**Prevent Microsoft from tracking your visits to other websites**

This Project is a fork of [Mozilla's Facebook Container](https://addons.mozilla.org/firefox/addon/facebook-container/) modified to work with microsoft.

*Note: This addon is not affliated to Mozilla in anyway*
